export const environment = {
  // Json para la conexión hacia la base de datos firebase en producción 
  firebase: {
    projectId: 'ang-proyect',
    appId: '1:130905455709:web:4a4b2a49f6a411cce9e1b4',
    databaseURL: 'https://ang-proyect-default-rtdb.firebaseio.com',
    storageBucket: 'ang-proyect.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDyVOyi3Yj9s9HVQuURuD_NMeyiYHb1uJQ',
    authDomain: 'ang-proyect.firebaseapp.com',
    messagingSenderId: '130905455709',
  },
  production: true
};
