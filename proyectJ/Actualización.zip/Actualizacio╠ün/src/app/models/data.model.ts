export class DataCrudModel{
    id: string;
    titulo: string;
    descripcion: string;
    year: number;
    image: string;
    video: string;
}
