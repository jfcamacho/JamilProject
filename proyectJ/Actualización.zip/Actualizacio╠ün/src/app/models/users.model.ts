export class UserModel {
    username: string;
    password: string;
}